// import './style.css'
// import javascriptLogo from './javascript.svg'
// import viteLogo from '/vite.svg'
// import { setupCounter } from './counter.js'
// script.js
        //  slider
        document.addEventListener('DOMContentLoaded', function () {
            const slider = document.querySelector('.slider');
            const slides = document.querySelectorAll('.slide');
            const prevButton = document.querySelector('.prev');
            const nextButton = document.querySelector('.next');
            let currentIndex = 0;
            let interval;

            function showSlide(index) {
                slider.style.transform = `translateX(-${index * 100}%)`;
            }

            function nextSlide() {
                currentIndex = (currentIndex + 1) % slides.length;
                showSlide(currentIndex);
            }

            function prevSlide() {
                currentIndex = (currentIndex - 1 + slides.length) % slides.length;
                showSlide(currentIndex);
            }

            function startSlider() {
                interval = setInterval(nextSlide, 3000);
            }

            function stopSlider() {
                clearInterval(interval);
            }

            nextButton.addEventListener('click', function () {
                stopSlider();
                nextSlide();
                startSlider();
            });

            prevButton.addEventListener('click', function () {
                stopSlider();
                prevSlide();
                startSlider();
            });

            slider.addEventListener('mouseenter', stopSlider);
            slider.addEventListener('mouseleave', startSlider);

            startSlider();
        });
        // slider end
         
        // Dom
  
    function dom() {
        //banner
        let Ads=document.querySelector('.My-ads');
        let Cross=document.querySelector('#Cross');
        Cross.addEventListener('click' , function(){
            Ads.style.display='none';
        })

        // menu
        let Menu=document.querySelector('#Menu1');
        let menu=document.querySelector('#menu');
        let closes=document.querySelector('.close');
        let navLogo=document.querySelector('.nav-part-logo');
        menu.addEventListener('click', function(){
            Menu.style.right='0%';
            menu.style.display='none';
            navLogo.style.display='none';
        })
        closes.addEventListener('click', function(){
            Menu.style.right='100%';
            menu.style.display='block';
            navLogo.style.display='block';
        })
          }

          dom()

         //dom end